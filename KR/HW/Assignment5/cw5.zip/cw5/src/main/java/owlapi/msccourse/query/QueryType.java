package owlapi.msccourse.query;

public enum QueryType {
	EQUIVALENTCLASSES,SUBCLASSES,INSTANCES;
}
